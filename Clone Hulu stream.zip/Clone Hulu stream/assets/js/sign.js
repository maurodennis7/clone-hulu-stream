import { closeModal, mostrarModal } from "./popup.js";
import { index } from "./login.js";
import * as validation from "./FunctionValidar.js";

const modal = document.querySelector("dialog");
const inputs = document.querySelectorAll("input");
const form = document.querySelector("form");

const inpName = document.querySelector('input#name');
const inpPass2 = document.querySelector('input#pass2');
const inpEmail = document.querySelector('input[type="email"]');
const inpPass = document.querySelector('input[type="password"]');

form.addEventListener("submit", (e) => {
    e.preventDefault();

    try{
        validarDados();
    } catch (error) {
        console.log(error);        
    }
});
function validarDados(){
    // Full Name
    const Name = validation.verifyName(inpName);
    // email adress    
    const Email = validation.verifyEmail(inpEmail);
    // password    
    const Password = validation.verifyPass(inpPass, inpPass2);
     // password2
    const Password2 = validation.verifyPass2(inpPass2);
    
    if(Name && Email && Password){
        setTimeout(() => {
            mostrarModal(modal);
        }, 1000);
    }
}

// close modal
document.querySelector("#closeModal").addEventListener("click", () => {
    closeModal(modal);
    inputs.forEach((input) =>{
        input.value = "";
        input.classList.remove('sucess');
    });
});