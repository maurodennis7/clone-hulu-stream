import * as validation from "./FunctionValidar.js";

const form = document.querySelector("form");
const modal = document.querySelector("dialog");
const inputs = document.querySelectorAll("input");

// Inputs
const inpEmail = document.querySelector('input[type="email"]');
const inpPass = document.querySelector('input[type="password"]');

document.addEventListener("DOMContentLoaded", () => {
   
    form.classList.add('form-animated');

});

export const index = document.querySelector("img#index");

index.addEventListener("click", () => {
    document.location.href = '/assets/html/index.html';
})



form.addEventListener("submit", (e) => {
    e.preventDefault();
    try{
        validarDados();
    } catch (error) {
        console.log(error);        
    }
});

function validarDados(){
    // o email    
    const Email = validation.verifyEmail(inpEmail);
    // a password    
    const Pass = validation.verifyPass(inpPass);

    if(Email && Pass){
        setTimeout(() => {
            document.location.href = '/assets/html/index.html';
        }, 1500);
    }
}

