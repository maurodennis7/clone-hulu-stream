export function mostrarModal(modal){
    modal.show();

    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.flexDirection = 'column';
    modal.style.gap = '2rem';
    modal.style.margin = 'auto';
}

export function closeModal(modal){
    modal.style.display = 'none';
}