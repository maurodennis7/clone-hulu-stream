import  * as MenuActive from "./LiActiveFunction.js";

    const activeMenu = document.querySelector("ul#list");
    const liActive = activeMenu.querySelectorAll("li");

    const sports = document.querySelector(".sports");
    const title = sports.querySelector(".title");

    const h1 = title.querySelector("h1");
    const p = title.querySelector("p");
    const camada = sports.querySelector(".camada-leve");

    LiActives();

    function setText1(h1, mainContent, camada, sports) {
        h1.innerText = `Live Sports`;
        mainContent.innerText = 
        `
            Catch your games at home or on the go. Stream live games from
            major college and pro leagues including the NCAA®, NBA, NHL,
            NFL, and more.
        `;
        title.classList.add('text-animated');

        camada.style.backgroundImage = 'linear-gradient(to top, #60c979, transparent)';
        sports.style.background = 'url(".././../images/ts.webp") no-repeat center';
        sports.style.backgroundSize = 'cover';
        camada.classList.add('sports-came-down');
    }

    function setText2(h1, mainContent, camada, sports) {
        h1.innerText = `Breaking News`;
        mainContent.innerText = 
        `
            Keep pace with what's going on locally and globally
            with trusted opinions from all the top news networks.
        `;
        title.classList.add('text-animated');

        camada.style.backgroundImage = 'linear-gradient(to top, #1c4cdb, transparent)';
        sports.style.background = 'url(".././../images/moo-xaxier.webp") no-repeat center';
        sports.style.backgroundSize = 'cover';
        camada.classList.add('sports-came-down');
    }
    function setText3(h1, mainContent, camada, sports) {
        h1.innerText = `Biggest Events`;
        mainContent.innerText = 
        `
           Spectacular, can't-miss moments like the Olympics,
           Grammys®, Oscars®, Emmys®, and more.
        `;
        title.classList.add('text-animated');

        camada.style.backgroundImage = 'linear-gradient(to top, #cf9713, transparent)';
        sports.style.background = 'url(".././../images/960x0.jpg") no-repeat center';
        sports.style.backgroundSize = 'cover';
        camada.classList.add('sports-came-down');
    }

   function LiActives() {
        liActive[0].addEventListener("click", (e) => {
            if(liActive[0].classList.contains('after-die')){
                liActive[0].classList.remove('after-die');
            }
            MenuActive.activeMenuLi(liActive);
            setText1(h1, p, camada, sports);
        })
        liActive[1].addEventListener("click", () => {
            MenuActive.activeMenuLi1(liActive);
            liActive[0].classList.add('after-die');
            setText2(h1, p, camada, sports);
            // o after morre
        })
        liActive[2].addEventListener("click", () => {
            MenuActive.activeMenuLi2(liActive);
            liActive[0].classList.add('after-die');
            setText3(h1, p, camada, sports);
        });
   }

// quando clicada o after se desloca
