
export function erroValidacao(input, span, sms){
    input.className = 'error';
    span.className = 'span2';

    return span.innerText = sms;
}
export function sucessoValidacao(input, sms){
    input.className = 'sucess';
    sms.className = 'span1';
}

export function verifyEmail(inpEmail) {
    // the email
    if(inpEmail.value === ''){ // se === vazio
        erroValidacao(inpEmail, setmessage(inpEmail), "Este campo é obrigatório");
        inpEmail.focus();
        return false;
    }else{// se !== vazio..
        if(!inpEmail.value.includes("@") || !inpEmail.value.includes("gmail.com")){
            erroValidacao(inpEmail, setmessage(inpEmail), "O endereço de e-mail está imcompleto");
            return false;
        }else if(inpEmail.value.includes("@") && inpEmail.value.includes("gmail.com")){ 
            sucessoValidacao(inpEmail, setmessage(inpEmail));
            return true;
        }else{
            alert("Erro Desconhecido!");
        }
    }
}
export function verifyPass(inpPass, inpPass2) {
    if(inpPass.value !== ''){ // se esiver good.
        inpPass.focus();
        if(inpPass.value.toString().length < 8){
            erroValidacao(inpPass, setmessage(inpPass), "A palavra-passe deve ter no minimo 8 caracteres")
            return false;
        }else if(inpPass2.value !== inpPass.value){
            erroValidacao(inpPass2,  setmessage(inpPass2), "A password não coincide");
        }else{
            sucessoValidacao(inpPass, setmessage(inpPass));
            if(inpPass2.value === ''){
                erroValidacao(inpPass2,  setmessage(inpPass2), "Este campo é obrigatório");
            }else{
                sucessoValidacao(inpPass2, setmessage(inpPass2));
            }
            return true;
        }
    }else{
       erroValidacao(inpPass, setmessage(inpPass), "Este campo é obrigatório");
        return false;
    }
}
export function verifyName(inpName){
    // the Name
    if(inpName.value === ''){ // se === vazio
        erroValidacao(inpName, setmessage(inpName), "Este campo é obrigatório");
        inpName.focus();
        return false;
    }else{// se !== vazio.. 
        sucessoValidacao(inpName, setmessage(inpName));
        return true;
    }
}
export function verifyPass2(inpPass2){
    // the password 2
    if(inpPass2.value === ''){
        erroValidacao(inpPass2, setmessage(inpPass2), 'Este campo é obrigatório');
        return false;
    }
}
export function setmessage(input){
    const divPai = input.parentElement;
    let msg = divPai.lastElementChild;
    return  msg;
}    