

export function activeMenuLi(liActive){
    liActive[1].classList.remove('activeLi');
    liActive[2].classList.remove('activeLi');
    liActive[0].classList.add('activeLi');
}
export function activeMenuLi1(liActive){
    liActive[0].classList.remove('activeLi');
    liActive[2].classList.remove('activeLi');
    liActive[1].classList.add('activeLi');
}
export function activeMenuLi2(liActive){
    liActive[0].classList.remove('activeLi');
    liActive[1].classList.remove('activeLi');
    liActive[2].classList.add('activeLi');
}