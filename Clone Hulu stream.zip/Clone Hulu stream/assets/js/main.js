const cards = document.querySelectorAll(".card")

const drop = document.querySelector("#dropdown");
const arrow = document.querySelector("#arrow");

const menu = document.querySelector("nav");
const divDrop = document.querySelector("#drop");

const divTransparent = document.querySelector('.additional-info');


function scroll(){
    if(scrollY > 0){
        menu.classList.add('menu-black');
    }else{
        menu.classList.remove('menu-black');
    }
    console.log("Scroll = "+scrollY);
    stopAnimation();
    zIndex(divTransparent);
}

function zIndex(element){
    if(scrollY >= 410){
        element.classList.add('zIndex');
        console.log("Alterou");
    }else{
        element.classList.remove('zIndex');
    }
}

function stopAnimation(){

    cards.forEach((card) => {
           card.classList.add('animated-card');
    });
    if(scrollY >= 980){
        cards.forEach((card) => {
           card.classList.remove('animated-card');
        });
    }
}

// Button to show the hidden content
const openContent = document.querySelector("#dropBtn");

let arrowUp = document.createElement("img");
setImageSrc(arrowUp);

document.querySelector("img#arrow").addEventListener("click", () => {
    setStyle(drop, openContent, divDrop);

    arrowUp.addEventListener("click" , () => {
        removeStyle(arrow, arrowUp, drop, divDrop);
    });
});

function setStyle(drop, openContent, divDrop){
    openContent.appendChild(arrowUp);
    arrow.style.display = 'none';
    arrowUp.style.display = 'initial';

    drop.style.display = 'block';
    drop.classList.remove('close-animation');
    drop.classList.add('animar');

    divDrop.classList.remove('pageUp');
    divDrop.classList.add('pageDown');
}

function removeStyle(arrow, arrowUp, drop, divDrop){
    arrow.style.display = 'initial';
    arrowUp.style.display = 'none';

    drop.classList.remove('animar');
    drop.classList.add('close-animation');
    drop.style.display = 'none';

    divDrop.classList.remove('pageDown');
    divDrop.classList.add('pageUp');
}

function setImageSrc(arrowUp) {
    arrowUp.src = '.././../images/arrowup.svg';
}

function animationEnd(drop){
    drop.addEventListener("animationend", () => {
        drop.style.display = 'none';
    });
}